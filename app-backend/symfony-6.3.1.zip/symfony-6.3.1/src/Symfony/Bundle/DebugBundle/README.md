DebugBundle
===========

DebugBundle provides a tight integration of the Symfony VarDumper component and
the ServerLogCommand from MonologBridge into the Symfony full-stack framework.

Resources
---------

 * [Contributing](https://symfony.com/doc/current/contributing/index.html)
 * [Report issues](https://github.com/symfony/symfony/issues) and
   [send Pull Requests](https://github.com/symfony/symfony/pulls)
   in the [main Symfony repository](https://github.com/symfony/symfony)
